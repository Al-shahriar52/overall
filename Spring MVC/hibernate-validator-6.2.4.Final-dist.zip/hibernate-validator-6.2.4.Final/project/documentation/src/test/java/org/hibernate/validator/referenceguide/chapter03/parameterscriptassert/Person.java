package org.hibernate.validator.referenceguide.chapter03.parameterscriptassert;

public class Person {
}
